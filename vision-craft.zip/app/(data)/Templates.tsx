export default [
  {
    name: "Blog Title",
    desc: "An AI tool that generate blog title depends on your blog information",
    category: "blog",
    icon: "https://cdn-icons-png.flaticon.com/128/2800/2800015.png",
    aiPrompt:
      "Give me 5 blog title idea in bullet wise only based on niche & outline and give me result in Rich text editor format",
    slug: "generate-blog-title",
    form: [
      {
        label: "Enter your blog niche",
        field: "input",
        name: "niche",
        required: true,
      },
      {
        label: "Enter blog outline",
        field: "textarea",
        name: "outline",
      },
    ],
  },
  {
    name: "Blog Content",
    desc: "An AI tool that serves as your personal blog post title content generator",
    category: "blog",
    icon: "https://cdn-icons-png.flaticon.com/128/8980/8980709.png",
    aiPrompt:
      "Give me 5 blog topic idea in bullet wise only based on niche & outline and give me result in Rich text editor format",
    slug: "blog-content-generation",
    form: [
      {
        label: "Enter your blog topic",
        field: "input",
        name: "niche",
        required: true,
      },
      {
        label: "Enter blog outline here",
        field: "textarea",
        name: "outline",
      },
    ],
  },
  {
    name: "Blog Topic Ideas",
    desc: "An AI tool that generate blog title depends on your blog information",
    category: "blog",
    icon: "https://cdn-icons-png.flaticon.com/128/4659/4659050.png",
    aiPrompt:
      "Generate top 5 Blog Topic Ideas in bullet wise only based on niche & outline and give me result in Rich text editor format",
    slug: "blog-topic-idea",
    form: [
      {
        label: "Enter your blog niche",
        field: "input",
        name: "niche",
        required: true,
      },
    ],
  },
  {
    name: "Youtube SEO Title",
    desc: "An AI tool that generate blog title depends on your blog information",
    category: "Youtube Tools",
    icon: "https://cdn-icons-png.flaticon.com/128/15302/15302398.png",
    aiPrompt:
      "Give me Best SEO optimized high ranked 5 title idea for youtube video in bullet wise only based on niche & outline and give me result in Rich text editor format",
    slug: "youtube-seo-title",
    form: [
      {
        label: "Enter your youtube video topic keywords",
        field: "input",
        name: "keywords",
        required: true,
      },
      {
        label: "Enter youtube description here",
        field: "textarea",
        name: "outline",
      },
    ],
  },
  {
    name: "Youtube Description",
    desc: "An AI tool that generate blog title depends on your blog information",
    category: "Youtube Tool",
    icon: "https://cdn-icons-png.flaticon.com/128/10885/10885022.png",
    aiPrompt:
      "Generate Youtube description with emoji under 4-5 lines in bullet wise only based on niche & outline and give me result in Rich text editor format",
    slug: "youtube-description",
    form: [
      {
        label: "Enter your blog topic/title",
        field: "input",
        name: "topic",
        required: true,
      },
      {
        label: "Enter youtube Outline here",
        field: "textarea",
        name: "outline",
      },
    ],
  },
  {
    name: "Youtube Tags",
    desc: "An AI tool that generate blog title depends on your blog information",
    category: "Youtube Tool",
    icon: "https://cdn-icons-png.flaticon.com/128/10884/10884882.png",
    aiPrompt:
      "Generate 10 Youtube tags in bullet wise only based on niche & outline and give me result in Rich text editor format",
    slug: "youtube-tag",
    form: [
      {
        label: "Enter your youtube title",
        field: "input",
        name: "title",
        required: true,
      },
      {
        label: "Enter youtube video Outline here (Optional)",
        field: "textarea",
        name: "outline",
      },
    ],
  },
  {
    name: "Rewrite Article Plagiarism Free",
    desc: "Use this tool to rewrite existing Article or Blog Post free of Plagiarism",
    category: "Rewriting Tool",
    icon: "https://cdn-icons-png.flaticon.com/128/2696/2696555.png",
    aiPrompt:
      "Rewrite given article without any Plagiarism in Rich text editor format",
    slug: "rewrite-article",
    form: [
      {
        label: "Provide your Article/Blogpost or any other content",
        field: "textarea",
        name: "article",
        required: true,
      },
    ],
  },
  {
    name: "Text Improver",
    desc: "This handy tool refines your writing, elimanating errors",
    category: "Writing Assistant",
    icon: "https://cdn-icons-png.flaticon.com/128/12860/12860749.png",
    aiPrompt:
      "Given test To Improve, Rewrite without any grammatical errors result in Rich text editor format",
    slug: "text-Improver",
    form: [
      {
        label: "Enter text that you want to re-write or Improve",
        field: "textarea",
        name: "textToImprove",
      },
    ],
  },
  {
    name: "Add Emojis to Text",
    desc: "An AI tool that serves as your personal blog post title",
    category: "blog",
    icon: "https://cdn-icons-png.flaticon.com/128/1464/1464029.png",
    aiPrompt:
      "Add Emoji to outline text depends on outline and give result in Rich text editor format",
    slug: "add-emoji-to-text",
    form: [
      {
        label: "Enter your text to add emojis",
        field: "textarea",
        name: "outline",
        required: true,
      },
    ],
  },
  {
    name: "Instagram Post Generator",
    desc: "An AI tool that generate blog title depends on your blog information",
    category: "blog",
    icon: "https://cdn-icons-png.flaticon.com/128/1384/1384063.png",
    aiPrompt:
      "Generate 3 Instagram post depends on a given keyword and give me result in Rich text editor format",
    slug: "instagram-post-generator",
    form: [
      {
        label: "Enter Keywords for your post",
        field: "input",
        name: "keywords",
        required: true,
      },
    ],
  },
];
